
<!DOCTYPE html>
<html>
<body>

<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
<?php require 'footer.php';
    echo"Hello";

?>

</body>
</html>