<!-- sidebar.php -->
<div id="sidebar" class="sidebar">
  <h3>Menú</h3>
  <ul>
    <li><a href="example_menu.php">Inicio</a></li>
    <li><a href="page1.php">Acerca de</a></li>
    <li><a href="page2.php">Contacto</a></li>
  </ul>
</div>


