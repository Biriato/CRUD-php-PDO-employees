<!-- sidebar.php -->
<div id="sidebar" class="sidebar">
  <h3>Menú</h3>
  <ul>
    <li><a href="forms_1.php">Forms 1</a></li>
    <li><a href="forms_2a.php">Forms 2</a></li>
    <li><a href="forms_3a.php">Forms 3</a></li>
    <li><a href="forms_4.php">Forms 4</a></li>
    <li><a href="forms_6.php">Forms 6</a></li>
    <li><a href="forms_7.php">Forms 7</a></li>
  </ul>
</div>


