<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="menu.css">
</head>
<body>
<?php include 'topmenu.php';?>
<div class="main-content">
<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
</div>


</body>
</html>