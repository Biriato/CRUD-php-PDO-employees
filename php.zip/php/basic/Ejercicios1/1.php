<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>1</title>
</head>
<body>
<h1>1</h1>
<?php  
$name = "Alejandro";
$age = 25;
$city = "Ourense";

echo "<p>Hello I'm $name and I'm $age years old and i like the city of $city</p>";
?>  
</body>
</html>