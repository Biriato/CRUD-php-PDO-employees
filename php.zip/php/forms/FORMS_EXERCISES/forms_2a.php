<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menu.css">
    <title>Forms2</title>
</head>
<body>
<?php include 'topmenu.php';?>
<div class="main-content">
    <form action="forms_2.php" method="get">
        Name: <input type="text" name="name"><br>
        Password: <input type="password" name="pass"><br>
        <input type="submit">
    </form>
</div>      
</body>
</html>