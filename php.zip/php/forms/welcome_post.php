<html>
<body>

Welcome <?php echo $_POST["namep"]; ?><br>
Your email address is: <?php echo $_POST["emailp"]; ?>

</body>
</html>