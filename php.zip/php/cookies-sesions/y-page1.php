<?php
    include "y-protect.php";
    echo "This is a protected page via login";
?>