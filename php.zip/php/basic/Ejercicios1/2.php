<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $base = 2.5;
    $height = 4.6;
    $area = $base*$height/2;
    echo "The base is $base , the height is $height and the area is $area";
    ?>
</body>
</html>